import xbmc
import sys

if __name__ == '__main__':
    xbmc.executebuiltin("ActivateWindow(1132)")
